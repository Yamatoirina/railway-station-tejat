package com.ra.course.station.dao;

import com.ra.course.station.entity.Passenger;
import com.ra.course.station.exception.DataException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import javax.sql.DataSource;
import java.sql.*;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class PassengerDaoMockTest {
    private PassengerDao passengerDao;
    private DataSource mockDataSource;
    private Connection mockConnection;
    private PreparedStatement mockStatement;
    private ResultSet mockResultSet;


    private static final String INSERT_SQL =
            "INSERT INTO passenger(name,email,phoneNumber,trainNumber,seatNumber) VALUES ( ?,?,?,?,?);";

    private static final String DELETE_SQL =
            "DELETE FROM passenger WHERE id = ?;";

    private static final String UPDATE_SQL =
            "UPDATE passenger SET name = ?,email = ?,phoneNumber=?,trainNumber=?,seatNumber=? WHERE id=?;";

    private static final String FIND_ONE_SQL = "SELECT *  FROM passenger WHERE passenger.id = ?;";

    private static final String FIND_ALL_SQL = "SELECT * FROM passenger";

    @BeforeEach
    void init() {
        mockDataSource = mock(DataSource.class);
        passengerDao = new PassengerDao(mockDataSource);
        mockConnection = mock(Connection.class);
        mockStatement = mock(PreparedStatement.class);
        mockResultSet = mock(ResultSet.class);
    }


    @Test
    void whenCallSave_ThenReturnPassenger() throws Exception {
        Passenger mockPassenger = mock(Passenger.class);
        mockResultSet = mock(ResultSet.class);
        when(mockDataSource.getConnection()).thenReturn(mockConnection);
        when(mockConnection.prepareStatement(INSERT_SQL, PreparedStatement.RETURN_GENERATED_KEYS)).thenReturn(mockStatement);
        when(mockStatement.executeUpdate()).thenReturn(1);
        when(mockStatement.getGeneratedKeys()).thenReturn(mockResultSet);
        when(mockResultSet.next()).thenReturn(true);
        when(mockResultSet.getLong(1)).thenReturn(1L);
        assertEquals(mockPassenger, passengerDao.save(mockPassenger));
    }



    @Test
    void whenCallSavePassenger_ThenThrowSQLException() throws Exception {
        Passenger mockPassenger = mock(Passenger.class);
        when(mockDataSource.getConnection()).thenThrow(new SQLException());
        assertThrows(DataException.class, () -> passengerDao.save(mockPassenger));
    }



    @Test
    void whenCallSave_ThenThrowExceptionInResultSet() throws SQLException {
        Passenger mockPassenger = mock(Passenger.class);
        when(mockDataSource.getConnection()).thenReturn(mockConnection);
        when(mockConnection.prepareStatement(INSERT_SQL, PreparedStatement.RETURN_GENERATED_KEYS)).thenReturn(mockStatement);
        when(mockStatement.executeUpdate()).thenReturn(0);
        when(mockStatement.getGeneratedKeys()).thenThrow(new SQLException());
        assertThrows(DataException.class, () -> passengerDao.save(mockPassenger));
    }


    @Test
    void whenCallSavePassenger_thenThrowDaoOperationException() throws Exception {
        Passenger mockPassenger = mock(Passenger.class);
        mockResultSet = mock(ResultSet.class);
        when(mockDataSource.getConnection()).thenReturn(mockConnection);
        when(mockConnection.prepareStatement(INSERT_SQL, PreparedStatement.RETURN_GENERATED_KEYS)).thenReturn(mockStatement);
        when(mockStatement.executeUpdate()).thenReturn(1);
        when(mockStatement.getGeneratedKeys()).thenReturn(mockResultSet);
        when(mockResultSet.next()).thenReturn(false);
        assertThrows(DataException.class,() ->passengerDao.save(mockPassenger));
    }

    @Test
    void whenCallFindOne_ThenReturnPassengerFromDb() throws Exception {
        mockResultSet = mock(ResultSet.class);
        when(mockDataSource.getConnection()).thenReturn(mockConnection);
        when(mockConnection.prepareStatement(FIND_ONE_SQL)).thenReturn(mockStatement);
        when(mockStatement.executeQuery()).thenReturn(mockResultSet);
        when(mockResultSet.next()).thenReturn(true);
        Passenger mockPassenger = passengerDao.findOne(1L);
        assertNotNull(mockPassenger);
    }



    @Test
    void whenCallFindOne_ThenThrowException() throws SQLException {
        mockResultSet = mock(ResultSet.class);
        when(mockDataSource.getConnection()).thenReturn(mockConnection);
        when(mockConnection.prepareStatement(FIND_ONE_SQL)).thenReturn(mockStatement);
        when(mockStatement.executeQuery()).thenReturn(mockResultSet);
        when(mockResultSet.next()).thenReturn(false);
        assertThrows(DataException.class, () -> passengerDao.findOne(1L));
    }

    @Test
    void whenCallFindById_ThenThrowSQLExceptionInConnection() throws SQLException {
        when(mockDataSource.getConnection()).thenThrow(new SQLException());
        assertThrows(DataException.class, () -> passengerDao.findOne(1L));
    }





    @Test
    void whenCallFindAllPassengers_ThenReturnActualSizeList() throws Exception {
        Statement mockStatement = mock(Statement.class);
        when(mockDataSource.getConnection()).thenReturn(mockConnection);
        when(mockConnection.createStatement()).thenReturn(mockStatement);
        when(mockStatement.executeQuery(FIND_ALL_SQL)).thenReturn(mockResultSet);
        when(mockResultSet.next()).thenReturn(true).thenReturn(true).thenReturn(false);
        assertEquals(passengerDao.findAll().size(), 2);
    }


    @Test
    void whenCallFindAll_ThenReturnItFromDb() throws SQLException {
        Statement mockStatement = mock(Statement.class);
        mockResultSet = mock(ResultSet.class);
        when(mockDataSource.getConnection()).thenReturn(mockConnection);
        when(mockConnection.createStatement()).thenReturn(mockStatement);
        when(mockStatement.executeQuery(FIND_ALL_SQL)).thenReturn(mockResultSet);
        when(mockResultSet.next()).thenReturn(true).thenReturn(false);
        List<Passenger> all = passengerDao.findAll();
        assertNotNull(all.get(0));
    }


    @Test
    void whenCallFindAllPassengers_ThenThrowSQLException() throws Exception {
        when(mockDataSource.getConnection()).thenThrow(new SQLException());
        assertThrows(DataException.class, () -> passengerDao.findAll());
    }


    @Test
    void whenCallUpdatePassenger_ThenUpdatePassengerInDatabase() throws Exception{
        Passenger mockPassenger = mock(Passenger.class);
        when(mockPassenger.getId()).thenReturn(1L);
        when(mockDataSource.getConnection()).thenReturn(mockConnection);
        when(mockConnection.prepareStatement(UPDATE_SQL)).thenReturn(mockStatement);
        when(mockStatement.executeUpdate()).thenReturn(1);
        assertTrue(passengerDao.update(mockPassenger));
    }


    @Test
    void whenCallUpdatePassenger_ThenThrowSQLException() throws Exception{
        Passenger mockPassenger = mock(Passenger.class);
        when(mockDataSource.getConnection()).thenThrow(new SQLException());
        assertThrows(DataException.class, () -> passengerDao.update(mockPassenger));
    }




    @Test
    void whenCallUpdatePassengerWithWrongId_ThenThrowException() throws SQLException {
        Passenger mockPassenger = mock(Passenger.class);
        when(mockPassenger.getId()).thenReturn(1L);
        when(mockDataSource.getConnection()).thenReturn(mockConnection);
        when(mockConnection.prepareStatement(UPDATE_SQL)).thenReturn(mockStatement);
        assertThrows(DataException.class, () -> passengerDao.update(mockPassenger));
    }



    @Test
    void whenCallUpdatePassengerWithoutRowsUpdate_ThenThrowException() throws SQLException {
        Passenger mockPassenger = mock(Passenger.class);
        when(mockPassenger.getId()).thenReturn(1L);
        when(mockDataSource.getConnection()).thenReturn(mockConnection);
        when(mockConnection.prepareStatement(UPDATE_SQL)).thenReturn(mockStatement);
        when(mockStatement.executeUpdate()).thenReturn(0);
        assertThrows(DataException.class, () -> passengerDao.update(mockPassenger));
    }




    @Test
    void whenCallDeletePassengerById_ThenReturnTrue() throws Exception {
        when(mockDataSource.getConnection()).thenReturn(mockConnection);
        when(mockConnection.prepareStatement(DELETE_SQL)).thenReturn(mockStatement);
        when(mockStatement.execute()).thenReturn(true);
        assertTrue(passengerDao.delete(1L));
    }

    @Test
    void whenCallDeletePassengerById_ThenThrowSQLException() throws Exception {
        when(mockDataSource.getConnection()).thenThrow(new SQLException());
        assertThrows(DataException.class, () -> passengerDao.delete(1L));
    }


    @Test
    void whenCallGetDataSource_ThenReturnIt() {
        DataSource dataSource = passengerDao.getDataSource();
        assertNotNull(dataSource);
    }


}

