package com.ra.course.station.connection;

import org.h2.jdbcx.JdbcDataSource;

import javax.sql.DataSource;

public final class JDBCConnection {
    private static final String DEFAULT_DB_NAME = "jdbc:h2:~/memo";
    private static final String DEFAULT_USERNAME = "sa";
    private static final String DEFAULT_PASSWORD = "sa";

    private JDBCConnection() {

    }



    public static DataSource createDefaultInMemoryH2DataSource() {
        final String url = formatH2ImMemoryDbUrl(DEFAULT_DB_NAME);
        return createInMemoryH2DataSource(url, DEFAULT_USERNAME, DEFAULT_PASSWORD);
    }

    public static DataSource createInMemoryH2DataSource(final String url, final String username, final String pass) {
        final JdbcDataSource h2DataSource = new JdbcDataSource();
        h2DataSource.setUser(username);
        h2DataSource.setUrl(url);
        h2DataSource.setPassword(pass);
        return h2DataSource;
    }

    private static String formatH2ImMemoryDbUrl(final String databaseName) {
        return String.format("jdbc:h2:mem:%s;DB_CLOSE_DELAY=-1;DB_CLOSE_ON_EXIT=false", databaseName);
    }

}
