package com.ra.course;

public class SimpleService {

    public int sumTwoNumbers(final int a, final int b) {
        return a + b;
    }
}
