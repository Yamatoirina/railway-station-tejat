package com.ra.course.station.dao;

import java.io.Serializable;
import java.util.List;

public interface GenericDao<T extends Serializable  > {

    T save(final T obj);

    T findOne(final long id);

    List<T> findAll();

    boolean update(final T obj);

    boolean delete(final long id);
}
