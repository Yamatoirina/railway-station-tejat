package com.ra.course.station.dao;

import com.ra.course.station.exception.DataException;
import com.ra.course.station.entity.Passenger;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.sql.DataSource;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PassengerDao implements GenericDao<Passenger> {

    private static final String INSERT_SQL =
            "INSERT INTO passenger(name,email,phoneNumber,trainNumber,seatNumber) VALUES ( ?,?,?,?,?);";

    private static final String DELETE_SQL =
            "DELETE FROM passenger WHERE id = ?;";

    private static final String UPDATE_SQL =
            "UPDATE passenger SET name = ?,email = ?,phoneNumber=?,trainNumber=?,seatNumber=? WHERE id=?;";

    private static final String FIND_ONE_SQL = "SELECT *  FROM passenger WHERE passenger.id = ?;";

    private static final String FIND_ALL_SQL = "SELECT * FROM passenger";

    private transient final DataSource dataSource;

    public DataSource getDataSource() {
        return dataSource;
    }

    public PassengerDao(final DataSource dataSource) {
        this.dataSource = dataSource;
    }

    private static final Logger LOGGER = LoggerFactory.getLogger(Passenger.class);


    @Override
    public Passenger save(final Passenger passenger) {

        try (Connection connection = dataSource.getConnection();
             PreparedStatement insertStatement = fillStatementWithPassengerData(connection.prepareStatement(INSERT_SQL,
                     PreparedStatement.RETURN_GENERATED_KEYS), passenger)) {
            executeUpdate(insertStatement, "Passenger was not created");
            try (ResultSet generatedKeys = insertStatement.getGeneratedKeys()) {
                if (generatedKeys.next()){
                    final Long id = generatedKeys.getLong(1);
                    passenger.setId(id);
                } else {
                    LOGGER.error("Error getting generated keys: %s");
                    throw new DataException("Error getting generated keys: %s");
                }
            }
            return passenger;
        } catch (SQLException e) {
            LOGGER.error("Error saving passenger: %s");
            throw new DataException(String.format("Error saving Passenger: %s", passenger), e);
        }

    }

    @Override
    public Passenger findOne(final long id) {
        try (Connection connection = dataSource.getConnection()) {
            final PreparedStatement selectById = connection.prepareStatement(FIND_ONE_SQL);
            selectById.setLong(1, id);
            final ResultSet resultSet = selectById.executeQuery();
            try {
                if (resultSet.next()) {
                    return parseRow(resultSet);
                } else {
                    LOGGER.error("Error finding passenger by id ");
                    throw new DataException("Error finding passenger by id ");
                }
            } finally {
                resultSet.close();
            }
        } catch (SQLException e) {
            LOGGER.error("Cannot find Passenger with id= %d");
            throw new DataException(String.format("Cannot find Passenger with id= %d", id), e);
        }
    }


    @Override
    public List<Passenger> findAll () {
        try (Connection connection = dataSource.getConnection();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(FIND_ALL_SQL)){
            final List<Passenger> passengerList = new ArrayList<>();
            while (resultSet.next()) {
                final Passenger passenger = parseRow(resultSet);
                passengerList.add(passenger);
            }
            return passengerList;
        } catch (SQLException e) {
            LOGGER.error(e.getMessage());
            throw new DataException(e.getMessage());
        }
    }


    @Override
    public boolean update ( final Passenger passenger){
        try (Connection connection = dataSource.getConnection()) {
            final PreparedStatement updateStatement = connection.prepareStatement(UPDATE_SQL);
            fillStatementWithPassengerData2(updateStatement, passenger);
            updateStatement.setLong(1, passenger.getId());
            executeUpdate(updateStatement, "Passenger was not updated");
            return true;
        } catch (SQLException e) {
            LOGGER.error(String.format("Error updating Passenger: %s", passenger), e);
            throw new DataException(
                    String.format("Cannot update Passenger where id=%d", passenger.getId()), e);
        }
    }

    @Override
    public boolean delete ( final long id){
        try (Connection connection = dataSource.getConnection()) {
            final PreparedStatement deleteStatement = connection.prepareStatement(DELETE_SQL);
            deleteStatement.setLong(1, id);
            return deleteStatement.execute();
        } catch (SQLException e) {
            LOGGER.error("Delete Passenger error", e);
            throw new DataException("Delete Passenger error", e);
        }

    }


    private PreparedStatement fillStatementWithPassengerData (
            final PreparedStatement insertStatement, final Passenger passenger) throws SQLException {
        insertStatement.setString(1, passenger.getName());
        insertStatement.setString(2, passenger.getEmail());
        insertStatement.setInt(3, passenger.getPhoneNumber());
        insertStatement.setInt(4, passenger.getTrainNumber());
        insertStatement.setInt(5, passenger.getSeatNumber());
       return insertStatement;
    }
    private PreparedStatement fillStatementWithPassengerData2 (
            final PreparedStatement insertStatement, final Passenger passenger) throws SQLException {
        insertStatement.setString(1, passenger.getName());
        insertStatement.setString(2, passenger.getEmail());
        insertStatement.setInt(3, passenger.getPhoneNumber());
        insertStatement.setInt(4, passenger.getTrainNumber());
        insertStatement.setInt(5, passenger.getSeatNumber());
        insertStatement.setLong(6, passenger.getId());
        return insertStatement;
    }
    private Passenger parseRow ( final ResultSet rs) throws SQLException {
        final Passenger passenger = new Passenger();
        passenger.setId(rs.getLong(1));
        passenger.setName(rs.getString(2));
        passenger.setEmail(rs.getString(3));
        passenger.setPhoneNumber(rs.getInt(4));
        passenger.setTrainNumber(rs.getInt(5));
        passenger.setSeatNumber(rs.getInt(6));
        return passenger;
    }


    private void executeUpdate ( final PreparedStatement insertStatement, final String errorMessage)
            throws SQLException {
        final int rowsAffected = insertStatement.executeUpdate();
        if (rowsAffected == 0) {
            LOGGER.error("Error during execution method executeUpdate", errorMessage);
            throw new DataException(errorMessage);
        }
    }

}