package com.ra.course.station;

    @SuppressWarnings("PMD")
    public class Main {
        public static void main(String[] args){

        }
    }


