package com.ra.course.station.connection;

import org.junit.jupiter.api.Test;

import javax.sql.DataSource;
import java.sql.SQLException;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class JDBCConnectionTest {

    @Test
    void createInMemoryH2DataSourceTest(){
        DataSource defaultInMemoryH2DataSource = JDBCConnection.createDefaultInMemoryH2DataSource();
      assertNotNull(defaultInMemoryH2DataSource);

    }

    @Test
    void createDefaultInMemoryH2DataSourceTest() throws SQLException {
        DataSource defaultInMemoryH2DataSource = JDBCConnection.createDefaultInMemoryH2DataSource();
        assertNotNull(defaultInMemoryH2DataSource);
        assertNotNull(defaultInMemoryH2DataSource.getConnection());

    }

    @Test
   void formatH2ImMemoryDbUrlTest(){
        DataSource inMemoryH2DataSource = JDBCConnection.createInMemoryH2DataSource("TEST", "TEST", "TEST");
        assertThrows(SQLException.class, inMemoryH2DataSource::getConnection);
    }
    }




