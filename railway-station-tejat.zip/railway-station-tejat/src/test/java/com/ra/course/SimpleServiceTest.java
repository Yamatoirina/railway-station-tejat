package com.ra.course;


import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class SimpleServiceTest {

    private SimpleService test = new SimpleService();

    @Test
    public void givenTwoNumbersThenReturnTheirSum() {
        Assertions.assertEquals(test.sumTwoNumbers(1, 2), 3);
    }
}
