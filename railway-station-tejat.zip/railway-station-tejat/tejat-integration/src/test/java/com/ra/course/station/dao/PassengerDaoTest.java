package com.ra.course.station.dao;

import com.ra.course.station.connection.JDBCConnection;
import com.ra.course.station.entity.Passenger;
import com.ra.course.station.exception.DataException;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import static org.junit.jupiter.api.Assertions.*;

public class PassengerDaoTest {
    private static GenericDao<Passenger> passengerDao;
    private static final Random random = new Random();
    private static DataSource dataSource;

    @BeforeAll
    static void before() throws SQLException {
        DataSource h2DataSource = JDBCConnection.createDefaultInMemoryH2DataSource();
        createPassengerTable(h2DataSource);
        passengerDao = new PassengerDao(h2DataSource);
    }

    private static void createPassengerTable(DataSource dataSource) throws SQLException {
        try (Connection connection = dataSource.getConnection()) {
            Statement statement = connection.createStatement();

            statement.execute("CREATE TABLE IF NOT EXISTS passenger(\n" +
                    " id INT AUTO_INCREMENT PRIMARY KEY,\n" +
                    " name VARCHAR (255) NOT NULL,\n" +
                    " email VARCHAR (255) UNIQUE NOT NULL,\n" +
                    " phoneNumber INTEGER(16),\n" +
                    " trainNumber INTEGER(16),\n" +
                    " seatNumber INTEGER(16) );");

            passengerDao = new PassengerDao(dataSource);
        }
    }


    @Test
    public void testSave() {
        Passenger passenger = generatePassenger();

        int passengerBeforeInsert = passengerDao.findAll().size();
        passengerDao.save(passenger);
        List<Passenger> passengerList = passengerDao.findAll();
        assertNotNull(passenger.getId());
        assertEquals(passengerBeforeInsert + 1, passengerList.size());
        assertTrue(passengerList.contains(passenger));
    }


    @Test
    public void testSaveInvalidPassenger() {
        Passenger invalidTestPassenger = generatePassenger();
        invalidTestPassenger.setName(null);
        try {
            passengerDao.save(invalidTestPassenger);
            fail("Exception was't thrown");
        } catch (Exception e) {
            assertEquals(DataException.class, e.getClass());
            assertEquals(String.format("Error saving Passenger: %s", invalidTestPassenger), e.getMessage());
        }
    }

    @Test
    public void testFindAll() {
        List<Passenger> newPassengers = generatePassengerList(5);
        List<Passenger> oldPassengers = passengerDao.findAll();
        newPassengers.forEach(passengerDao::save);
        List<Passenger> passengers = passengerDao.findAll();
        assertTrue(passengers.containsAll(oldPassengers));
        assertTrue(passengers.containsAll(newPassengers));
        assertEquals(oldPassengers.size() + newPassengers.size(), passengers.size());
    }


    @Test
    public void testFindOne() {
        Passenger testPassenger = generatePassenger();
        passengerDao.save(testPassenger);
        Passenger passenger = passengerDao.findOne(testPassenger.getId());
        assertEquals(testPassenger, passenger);
        assertEquals(testPassenger.getPhoneNumber(), passenger.getPhoneNumber());
        assertEquals(testPassenger.getName(), passenger.getName());
        assertEquals(testPassenger.getEmail(), passenger.getEmail());
        assertEquals(testPassenger.getTrainNumber(), passenger.getTrainNumber());
        assertEquals(testPassenger.getSeatNumber(), passenger.getSeatNumber());

    }

    @Test
    public void testUpdate() {
        Passenger passenger = generatePassenger();
        passengerDao.save(passenger);
        int passengersInDb = passengerDao.findAll().size();
        passenger.setName("Test-Test");
        passengerDao.update(passenger);
        int passengersAfterUpdateInDb = passengerDao.findAll().size();
        Passenger updatedFromDb = passengerDao.findOne(passenger.getId());
        assertNotEquals(passenger, updatedFromDb);
        assertEquals(passengersInDb, passengersAfterUpdateInDb);
    }

    @Test
    void deletePassengerTest() {
        Passenger passenger = generatePassenger();
        passengerDao.save(passenger);
        List<Passenger> beforeRemoveList = passengerDao.findAll();
        passengerDao.delete(passenger.getId());
        List<Passenger> afterRemoveList = passengerDao.findAll();
        assertEquals(beforeRemoveList.size(), afterRemoveList.size() + 1);
        assertFalse(afterRemoveList.contains(passenger));


    }



    private Passenger generatePassenger() {
        Passenger passenger = new Passenger();
        passenger.setName(String.valueOf(random.nextInt(1000)));
        passenger.setEmail(String.valueOf(random.nextInt(1000)));
        passenger.setPhoneNumber(random.nextInt(1000000));
        passenger.setTrainNumber(random.nextInt(1000000));
        passenger.setSeatNumber(random.nextInt(1000000));

        return passenger;
    }

    private List<Passenger> generatePassengerList(int size) {
        List<Passenger> list = new ArrayList<>();
        for (int i = 0; i < size; i++) {
            list.add(generatePassenger());
        }
        return list;
    }



}
